/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.mypackage.hello.NameHandler;

import java.time.LocalDate;
import java.time.Period;
import java.time.format.DateTimeFormatter;
import java.util.Calendar;
import java.util.GregorianCalendar;

/**
 *
 * @author SG702-13
 */
public class NameHandler {

    String name;
    Calendar cal = new GregorianCalendar();
    String fecha;
    String ingreso;
    String fecha2;
    int dia, mes, year;

    public NameHandler() {
        name = null;
        fecha = null;
        ingreso = null;
        this.cal =Calendar.getInstance();
        this.dia = cal.get(Calendar.DATE);
        this.mes = cal.get(Calendar.MONTH);
        this.mes++;
        this.year = cal.get(Calendar.YEAR);

    }

    public void calcularEdad(String fecha) {

        DateTimeFormatter date = DateTimeFormatter.ofPattern("dd/MM/yyyy");
        LocalDate fechaNacimiento = LocalDate.parse(fecha, date);
        LocalDate fechaActual = LocalDate.now();
        Period periodo = Period.between(fechaNacimiento, fechaActual);
        String resultado = ("Tienes: " + periodo.getYears() + " años " + periodo.getMonths() + " meses y " + periodo.getDays() + " dias");
        System.out.println(resultado);
        this.fecha = resultado;

    }

    public void calcularSemestre(String semestre) {
        String[] semestreArr = semestre.split("-");
        int[] semestreAux = new int[semestreArr.length];
        for (int i = 0; i < semestreAux.length; i++) {
            semestreAux[i] = Integer.parseInt(semestreArr[i]);

        }
        if (this.mes <= 6 && semestreAux[1] == 1) {
            int proceso = this.year - semestreAux[0];
            proceso = proceso * 2;
            proceso++;
            this.ingreso = Integer.toString(proceso);
        }
        if (this.mes <= 6 && semestreAux[1] == 2) {
            int proceso = this.year - semestreAux[0];
            proceso = proceso * 2;
            this.ingreso = Integer.toString(proceso);
        }
        if (this.mes > 6 && semestreAux[1] == 1) {
            int proceso = this.year - semestreAux[0];
            proceso = proceso * 2;
            proceso = proceso + 2;
            this.ingreso = Integer.toString(proceso);
        }
        if (this.mes > 6 && semestreAux[1] == 2) {
            int proceso = this.year - semestreAux[0];
            proceso = proceso * 2;
            proceso = proceso + 1;
            this.ingreso = Integer.toString(proceso);
        }
    }

    public String getIngreso() {
        return ingreso;
    }

    public void setIngreso(String ingreso) {
        this.ingreso = ingreso;
        calcularSemestre(this.ingreso);
    }

    public String getFecha() {
        return fecha;
    }

    public void setFecha(String fecha) {
        this.fecha = fecha;
        calcularEdad(fecha);
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
}
