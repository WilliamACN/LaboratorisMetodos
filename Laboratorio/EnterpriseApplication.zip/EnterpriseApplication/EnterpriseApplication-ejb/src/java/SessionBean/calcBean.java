/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package SessionBean;

import javax.ejb.Stateless;

/**
 *
 * @author Acer
 */
@Stateless
public class calcBean implements calcBeanLocal {

    @Override
    public Integer addition(int a, int b) {
        return (a + b);
    }

    // Add business logic below. (Right-click in editor and choose
    // "Insert Code > Add Business Method")
    @Override
    public Integer rest(int c, int d) {
        return (c - d);
    }

    @Override
    public Integer muntiplication(int e, int f) {
        return (e * f);
    }

    @Override
    public Integer division(int g, int h) {
        int resultado = 0;

        if (h == 0) {
            System.out.println("Error");
        } else {
            resultado = (g / h);
        }
        return resultado;
    }

}
